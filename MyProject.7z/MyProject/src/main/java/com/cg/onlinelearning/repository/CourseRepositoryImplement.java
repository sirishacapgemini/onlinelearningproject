package com.cg.onlinelearning.repository;
import java.util.*;
import java.util.List;
import com.cg.onlinelearning.dto.Course;
import com.cg.onlinelearning.dto.Student;
import com.cg.onlinelearning.exception.CourseNotFoundException;
import com.cg.onlinelearning.util.DBUtil;
public class CourseRepositoryImplement implements CourseRepository{
	public Course save(Course course) {
		// TODO Auto-generated method stub
		 DBUtil.courseList.add(course);
		 return course;}
    public List<Course> showAllCourses() {
// TODO Auto-generated method stub
		return DBUtil.courseList;}
public Course findBySubject(String subject) throws CourseNotFoundException{
	List<Student> stu=new ArrayList();
		for(Course course:DBUtil.courseList) {
			if(course.getSubject().equals(subject)){
				return course;
				}
			}
		throw new CourseNotFoundException("course not found");
}}
