package com.cg.onlinelearning.exception;

public class CourseNotFoundException extends Exception {
public CourseNotFoundException() {
	super();}
public CourseNotFoundException(String s) {
	super(s);
}}
