package com.cg.onlinelearning.service;
import java.util.List;
import com.cg.onlinelearning.dto.Course;
import com.cg.onlinelearning.dto.Student;
import com.cg.onlinelearning.exception.CourseNotFoundException;
public interface CourseService {
public Course registerForCourse(String subject,Student students) throws CourseNotFoundException;
public Course add(Course course);
public List<Student> searchBySubject(String subject) throws CourseNotFoundException;
public List<Course> showAllCourses();}
