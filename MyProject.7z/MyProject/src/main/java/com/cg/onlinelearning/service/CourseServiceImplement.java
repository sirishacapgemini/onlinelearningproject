package com.cg.onlinelearning.service;
import java.util.*;
import com.cg.onlinelearning.repository.*;
import com.cg.onlinelearning.dto.Course;
import com.cg.onlinelearning.dto.Student;
import com.cg.onlinelearning.exception.CourseNotFoundException;
import com.cg.onlinelearning.repository.CourseRepository;
import com.cg.onlinelearning.util.DBUtil;
public class CourseServiceImplement implements CourseService{
	private CourseRepository repository;
	public CourseServiceImplement() {
		repository=new CourseRepositoryImplement();}
	public Course registerForCourse(String subject, Student student) throws CourseNotFoundException{
		// TODO Auto-generated method stub
		Course cou=repository.findBySubject(subject);
		if(cou!=null) {
			List<Student> stu=new ArrayList<Student>();
			if(cou.getStudents()==null)
				stu.add(student);
			else {
				stu=cou.getStudents();
				stu.add(student);
			}
			cou.setStudents(stu);
			return repository.save(cou);
		}
		throw new CourseNotFoundException("course not found");

	}
public Course add(Course course) {
		// TODO Auto-generated method stub
		repository.save(course);
		return course;
		}
public List<Student> searchBySubject(String subject) throws CourseNotFoundException{
	Course cou=repository.findBySubject(subject);
	    	return cou.getStudents();
}
	public List<Course> showAllCourses() {
		// TODO Auto-generated method stub
		return repository.showAllCourses();}
	}
