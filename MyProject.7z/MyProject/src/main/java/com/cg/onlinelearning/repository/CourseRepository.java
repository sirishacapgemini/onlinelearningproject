package com.cg.onlinelearning.repository;
import java.util.List;
import com.cg.onlinelearning.dto.Course;
import com.cg.onlinelearning.dto.Student;
import com.cg.onlinelearning.exception.CourseNotFoundException;
public interface CourseRepository {
 public Course save(Course course);
 public Course findBySubject(String subject) throws CourseNotFoundException;
 public List<Course> showAllCourses();
}
