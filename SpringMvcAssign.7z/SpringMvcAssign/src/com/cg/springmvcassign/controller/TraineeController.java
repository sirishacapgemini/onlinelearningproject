package com.cg.springmvcassign.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.springmvcassign.dto.Trainee;
import com.cg.springmvcassign.service.TraineeService;



@Controller
public class TraineeController {
	//@RequestMapping(name="login",method=RequestMethod.GET)
	@Autowired
	TraineeService service;
	@GetMapping("login")
	public String getLogin() {
		
		return "myLogin";
		
	}
	@PostMapping("checkLogin")
	public String doLogin(@RequestParam("uname") String user,@RequestParam("upass") String pass) {
		System.out.println("checkLogin.........");
		if(user.equals("admin") && pass.equals("12345"))
			return "listPage";
		else
		return "error";
		
	}
	@GetMapping("addpage")
	public ModelAndView getAddTrainee(@ModelAttribute("tra") Trainee trainee,Map<String,Object> map,Map<String,Object> mapOne)
	{
	     List<String> listOfDomains=new ArrayList<>();
	     List<String> listOfPlaces=new ArrayList<>();
	     listOfDomains.add("Development");
	     listOfDomains.add("Testing");
	     listOfDomains.add("Bpo");
	     listOfPlaces.add("Hyderabad");
	     listOfPlaces.add("Chennai");
	     listOfPlaces.add("Pune");
	     listOfPlaces.add("Banglore");
	     listOfPlaces.add("Mumbai");
	     map.put("dom", listOfDomains);
	     mapOne.put("places", listOfPlaces);
		return new ModelAndView("addtraniee");
		
	}
	@PostMapping("addtraniee")
	public ModelAndView addTrainee(@ModelAttribute("tra") Trainee trainee) {
		Trainee train=service.addTrainee(trainee);
		return new ModelAndView("success","key",train);
	}
	@GetMapping("showpage")
	public ModelAndView showTrainee() {
		List<Trainee> myAllTrainees=service.showTrainees();
		return new ModelAndView("showall", "showtrainee", myAllTrainees);
		
	}
	@GetMapping("updatepage")
	public ModelAndView getUpdateTrainee(@ModelAttribute("tra") Trainee trainee) {
		return new ModelAndView("updatetrainee");
	
}
	@PostMapping("updatetraniee")
	public ModelAndView getUpdateTrain(@ModelAttribute("tra") Trainee trainee) {
		Trainee train=service.SearchById(trainee.getTraineeId());
		System.out.println(train);
		return new ModelAndView("updated","keyOne",train);
	
}
	@PostMapping("retrievepage")
	public ModelAndView updateTrainee(@ModelAttribute("tra") Trainee trainee) {
		System.out.println(trainee);
		Trainee train=service.update(trainee);
		
		return new ModelAndView("retrieve","keyOne",train);
		
		
		
}
	@GetMapping("search")
	public ModelAndView getSearch(@ModelAttribute("tra") Trainee trainee) {
		return new  ModelAndView("searchpage");
}
	@PostMapping("searchTrainee")
	public ModelAndView searchTrainee(@ModelAttribute("tra") Trainee trainee) {
		Trainee train=service.SearchById(trainee.getTraineeId());
		return new ModelAndView("retrieve","keyOne",train);
	}
	@GetMapping("deletepage")
	public ModelAndView delete(@ModelAttribute("tra") Trainee trainee) {
		return new ModelAndView("delete");
	}
	@PostMapping("deleteTrainee")
	public ModelAndView deleteTrainee(@ModelAttribute("tra") Trainee trainee) {
		service.deleteById(trainee.getTraineeId());
		return new ModelAndView("retrieve");
		
	}
}