package com.cg.springmvcassign.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.springmvcassign.dao.TraineeDao;
import com.cg.springmvcassign.dto.Trainee;
@Service("service")
public class TraineeServiceImpl implements TraineeService{
	@Autowired
    TraineeDao dao;
	@Override
	public Trainee addTrainee(Trainee trainee) {
		return dao.save(trainee);
	}

	@Override
	public List<Trainee> showTrainees() {
		// TODO Auto-generated method stub
		return dao.showTrainees();
	}

	
	@Override
	public Trainee SearchById(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id);
	}

	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		dao.deleteById(id);
		
	}

	@Override
	public Trainee update(Trainee trainee) {
		// TODO Auto-generated method stub
		Trainee tra=dao.findById(trainee.getTraineeId());
		tra.setTraineeId(trainee.getTraineeId());
		tra.setTraineeName(trainee.getTraineeName());
		tra.setTraineeDomain(trainee.getTraineeDomain());
		tra.setTraineeLocation(trainee.getTraineeLocation());
		return trainee;
	}

	

}
