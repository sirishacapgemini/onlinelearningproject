package com.cg.springmvcassign.service;

import java.util.List;


import com.cg.springmvcassign.dto.Trainee;

public interface TraineeService {
	public Trainee addTrainee(Trainee trainee);
	public List<Trainee> showTrainees();
	public Trainee SearchById(int id);
	public void deleteById(int id);
	public Trainee update(Trainee tra);
	
}
