package com.cg.springmvcassign.dao;

import java.util.List;

import com.cg.springmvcassign.dto.Trainee;

public interface TraineeDao {
	public Trainee save(Trainee trainee);
	public List<Trainee> showTrainees();
	public Trainee findById(int id);
	public void deleteById(int id);
}
