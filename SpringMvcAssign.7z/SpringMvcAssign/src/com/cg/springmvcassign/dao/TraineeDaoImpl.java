package com.cg.springmvcassign.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;


import com.cg.springmvcassign.dto.Trainee;
@Repository("dao")
public class TraineeDaoImpl implements TraineeDao{

	public static List<Trainee> myList=new ArrayList<>();
	@Override
	public Trainee save(Trainee trainee) {
		// TODO Auto-generated method stub
		Trainee tra=findById(trainee.getTraineeId());
		if(tra==null) {
		myList.add(trainee);
		
		}
		//return tra;
		
		return trainee;
		
	}

	@Override
	public List<Trainee> showTrainees() {
		// TODO Auto-generated method stub
		return myList;
	}

	@Override
	public Trainee findById(int id) {
		// TODO Auto-generated method stub
		for (Trainee trainee : myList) {
			if(trainee.getTraineeId()==id) 
				return trainee;
		}
		return null;
	}

	@Override
	public void deleteById(int id) {
		// TODO Auto-generated method stub
		if(findById(id)!=null)
			myList.remove(findById(id));
		
	}

}
